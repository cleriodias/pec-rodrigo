<?php

namespace App\Support;

use App\Models\ConfiguracaoFiscal;
use App\Models\NotaFiscal;
use App\Models\Produto;
use App\Models\ProdutoTributacaoFiscalUnidade;
use App\Models\VendaPagamento;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;
use RuntimeException;

class FiscalInvoicePreparationService
{
    private readonly FiscalTaxLimitService $fiscalTaxLimitService;

    public function __construct(
        private readonly FiscalCertificateService $fiscalCertificateService,
        private readonly FiscalNfceXmlService $fiscalNfceXmlService,
        private readonly FiscalMunicipalityCodeService $fiscalMunicipalityCodeService,
        ?FiscalTaxLimitService $fiscalTaxLimitService = null,
    ) {
        $this->fiscalTaxLimitService = $fiscalTaxLimitService ?? new FiscalTaxLimitService();
    }

    public function prepareForPayment(
        VendaPagamento $payment,
        ?array $consumer = null,
        bool $forceFiscalSignature = false,
        bool $forceNewNumber = false,
        bool $refreshFiscalConfiguration = false,
        bool $bypassFiscalGenerationDisabled = false,
    ): ?NotaFiscal
    {
        $payment->loadMissing([
            'vendas.produto',
            'vendas.unidade',
        ]);

        if ($payment->vendas->isEmpty()) {
            return null;
        }

        $firstSale = $payment->vendas->first();
        $unitId = (int) ($firstSale->id_unidade ?? 0);

        if ($unitId <= 0) {
            return null;
        }

        try {
            return DB::transaction(function () use ($payment, $unitId, $consumer, $forceFiscalSignature, $forceNewNumber, $refreshFiscalConfiguration, $bypassFiscalGenerationDisabled) {
                $config = null;
                $invoice = NotaFiscal::query()
                    ->where('tb4_id', $payment->tb4_id)
                    ->lockForUpdate()
                    ->first();

                if ($invoice) {
                    $configQuery = ConfiguracaoFiscal::query()
                        ->where('tb2_id', $unitId);

                    if ($forceNewNumber) {
                        $configQuery->lockForUpdate();
                    }

                    $config = $configQuery->first();
                } else {
                    $config = ConfiguracaoFiscal::query()
                        ->where('tb2_id', $unitId)
                        ->lockForUpdate()
                        ->first();

                    if ($config) {
                        $config = $this->fiscalTaxLimitService->reactivateAutomaticGenerationIfEligible($config);
                    }

                    if (! $this->shouldPrepareFiscalInvoiceForNewPayment($config, $payment->tipo_pagamento, $bypassFiscalGenerationDisabled)) {
                        return null;
                    }

                    // Revalida a existencia da nota apos obter o lock da configuracao:
                    // se outra transacao acabou de criar a nota, nao devemos consumir nova numeracao.
                    $invoice = NotaFiscal::query()
                        ->where('tb4_id', $payment->tb4_id)
                        ->lockForUpdate()
                        ->first();
                }

                if (! $this->supportsAutomaticFiscalGenerationForPaymentType($payment->tipo_pagamento)) {
                    if (! $invoice) {
                        return null;
                    }

                    if (in_array((string) $invoice->tb27_status, ['emitida', 'cancelada'], true)) {
                        return $invoice;
                    }

                    $message = $this->buildNonFiscalPaymentMessage($payment->tipo_pagamento);

                    $invoice->fill([
                        'tb27_status' => 'erro_validacao',
                        'tb27_erros' => [$message],
                        'tb27_ultima_tentativa_em' => now(),
                        'tb27_mensagem' => $message,
                    ]);
                    $invoice->save();

                    return $invoice;
                }

                $nextNumber = $invoice?->tb27_numero;
                $serie = $invoice?->tb27_serie;
                $modelo = $invoice?->tb27_modelo ?? 'nfce';
                $ambiente = $config?->tb26_ambiente ?? 'homologacao';

                if ($config && ($forceNewNumber || $nextNumber === null) && ($config->tb26_emitir_nfce || $config->tb26_emitir_nfe)) {
                    $nextNumber = (int) $config->tb26_proximo_numero;
                    $serie = $config->tb26_serie;
                    $modelo = $config->tb26_emitir_nfce ? 'nfce' : ($config->tb26_emitir_nfe ? 'nfe' : 'nfce');

                    $config->update([
                        'tb26_proximo_numero' => $nextNumber + 1,
                    ]);
                }

                [$eligibleSales, $excludedItems] = $this->splitSalesForFiscal($payment);
                $rtcTaxSnapshots = $this->resolveRtcTaxSnapshots($invoice, $eligibleSales, $config, $unitId, $refreshFiscalConfiguration);
                $consumerPayload = $this->resolveConsumerPayload($invoice, $consumer);
                $payload = $this->buildPayload(
                    $payment,
                    $config,
                    $modelo,
                    $ambiente,
                    $serie,
                    $nextNumber,
                    $consumerPayload,
                    $eligibleSales,
                    $excludedItems,
                    $rtcTaxSnapshots,
                );
                $errors = $this->validatePayload($payment, $config, $modelo, $consumerPayload, $eligibleSales, $excludedItems, $rtcTaxSnapshots);
                $status = $this->resolveStatus($config, $errors);
                $signedXml = null;
                $accessKey = null;

                $deferFiscalSignature = $this->shouldDeferFiscalSignatureForPayment(
                    $payment->tipo_pagamento,
                    $forceFiscalSignature,
                ) && ! filled($invoice?->tb27_xml_envio);

                if ($errors === [] && $config && $modelo === 'nfce' && ! $deferFiscalSignature) {
                    try {
                        $certificateData = $this->fiscalCertificateService->loadCertificateForConfiguration($config);
                        $xmlPayload = $this->fiscalNfceXmlService->buildSignedXml(
                            $invoice ?? new NotaFiscal([
                                'tb27_modelo' => $modelo,
                                'tb27_serie' => $serie,
                                'tb27_numero' => $nextNumber,
                            ]),
                            $payment,
                            $eligibleSales,
                            $consumerPayload,
                            $config,
                            $certificateData,
                            $rtcTaxSnapshots,
                        );

                        $signedXml = $xmlPayload['xml'];
                        $accessKey = $xmlPayload['access_key'];
                        $status = 'xml_assinado';
                    } catch (RuntimeException $exception) {
                        $errors[] = $exception->getMessage();
                        $status = 'erro_validacao';
                    }
                }

                if (! $invoice) {
                    $invoice = new NotaFiscal([
                        'tb4_id' => $payment->tb4_id,
                    ]);
                }

                $invoice->fill([
                    'tb2_id' => $unitId,
                    'tb26_id' => $config?->tb26_id,
                    'tb27_modelo' => $modelo,
                    'tb27_ambiente' => $ambiente,
                    'tb27_serie' => $serie,
                    'tb27_numero' => $nextNumber,
                    'tb27_status' => $status,
                    'tb27_payload' => $payload,
                    'tb27_erros' => $errors,
                    'tb27_chave_acesso' => $accessKey,
                    'tb27_xml_envio' => $signedXml,
                    'tb27_ultima_tentativa_em' => now(),
                    'tb27_mensagem' => $this->buildStatusMessage($status, $errors, $payload),
                ]);

                if ($forceNewNumber) {
                    $invoice->fill([
                        'tb27_protocolo' => null,
                        'tb27_recibo' => null,
                        'tb27_xml_retorno' => null,
                        'tb27_emitida_em' => null,
                        'tb27_cancelada_em' => null,
                    ]);
                }

                $invoice->save();
                $this->fiscalTaxLimitService->blockAutomaticGenerationIfLimitReached($invoice);

                return $invoice;
            }, 3);
        } catch (QueryException $exception) {
            if ($this->isLockWaitTimeout($exception)) {
                throw new RuntimeException(
                    'Outra operacao fiscal da mesma loja ainda esta em andamento. Aguarde alguns segundos e tente novamente.',
                    previous: $exception
                );
            }

            throw $exception;
        }
    }

    public function reprocessPendingInvoicesForUnit(int $unitId): int
    {
        $invoices = NotaFiscal::query()
            ->where('tb2_id', $unitId)
            ->whereIn('tb27_status', [
                'pendente_configuracao',
                'erro_validacao',
                'pendente_emissao',
                'xml_assinado',
                'erro_transmissao',
            ])
            ->with('pagamento.vendas.produto', 'pagamento.vendas.unidade')
            ->get();

        foreach ($invoices as $invoice) {
            if ($invoice->pagamento) {
                $this->prepareForPayment($invoice->pagamento);
            }
        }

        return $invoices->count();
    }

    private function buildPayload(
        VendaPagamento $payment,
        ?ConfiguracaoFiscal $config,
        string $modelo,
        string $ambiente,
        ?string $serie,
        ?int $numero,
        ?array $consumer,
        $eligibleSales,
        array $excludedItems,
        array $rtcTaxSnapshots,
    ): array {
        $sales = $payment->vendas;
        $unit = $sales->first()?->unidade;
        $documentTotal = round((float) $eligibleSales->sum('valor_total'), 2);
        $consumer = $this->normalizeConsumerPayload($consumer);

        return [
            'pagamento_id' => (int) $payment->tb4_id,
            'modelo' => $modelo,
            'ambiente' => $ambiente,
            'serie' => $serie,
            'numero' => $numero,
            'tipo_pagamento' => $payment->tipo_pagamento,
            'tef' => [
                'integrado' => (bool) $payment->tef_integrado,
                'autorizacao' => $payment->tef_autorizacao,
                'cnpj_credenciadora' => $payment->tef_cnpj_credenciadora,
                'bandeira' => $payment->tef_bandeira,
                'terminal' => $payment->tef_terminal,
                'transacao_em' => optional($payment->tef_transacao_em)?->toIso8601String(),
            ],
            'valor_total_venda' => round((float) $payment->valor_total, 2),
            'valor_total_documento' => $documentTotal,
            'itens_excluidos_qtd' => count($excludedItems),
            'consumer' => $consumer,
            'emitente' => [
                'unit_id' => (int) ($unit?->tb2_id ?? 0),
                'nome_unidade' => $unit?->tb2_nome,
                'cnpj' => $unit?->tb2_cnpj,
                'configuracao' => [
                    'razao_social' => $config?->tb26_razao_social,
                    'nome_fantasia' => $config?->tb26_nome_fantasia,
                    'ie' => $config?->tb26_ie,
                    'crt' => $config?->tb26_crt,
                    'exigir_tef_integrado' => (bool) ($config?->tb26_exigir_tef_integrado ?? false),
                    'logradouro' => $config?->tb26_logradouro,
                    'numero' => $config?->tb26_numero,
                    'bairro' => $config?->tb26_bairro,
                    'municipio' => $config?->tb26_municipio,
                    'codigo_municipio' => $config?->tb26_codigo_municipio,
                    'uf' => $config?->tb26_uf,
                    'cep' => $config?->tb26_cep,
                    'certificado_nome' => $config?->tb26_certificado_nome,
                    'certificado_cnpj' => $config?->tb26_certificado_cnpj,
                ],
            ],
            'itens' => $eligibleSales->map(function ($sale) {
                /** @var Produto|null $product */
                $product = $sale->produto;
                $productName = $this->resolveFiscalProductName($sale);

                return [
                    'produto_id' => (int) $sale->tb1_id,
                    'descricao' => $productName,
                    'quantidade' => (int) $sale->quantidade,
                    'valor_unitario' => round((float) $sale->valor_unitario, 2),
                    'valor_total' => round((float) $sale->valor_total, 2),
                    'ncm' => $product?->tb1_ncm,
                    'cest' => $product?->tb1_cest,
                    'cfop' => $product?->tb1_cfop,
                    'origem' => $product?->tb1_origem,
                    'csosn' => $product?->tb1_csosn,
                    'cst' => $product?->tb1_cst,
                    'aliquota_icms' => $product?->tb1_aliquota_icms,
                    'unidade_comercial' => $product?->tb1_unidade_comercial,
                    'unidade_tributavel' => $product?->tb1_unidade_tributavel,
                    'codigo_barras' => $product?->tb1_codbar,
                ];
            })->values()->all(),
            'itens_excluidos' => $excludedItems,
            'tributacao_rtc_2026' => $rtcTaxSnapshots,
        ];
    }

    private function validatePayload(
        VendaPagamento $payment,
        ?ConfiguracaoFiscal $config,
        string $modelo,
        ?array $consumer,
        $eligibleSales,
        array $excludedItems,
        array $rtcTaxSnapshots,
    ): array
    {
        $errors = [];

        if (! $config) {
            return ['Configure a emissao fiscal da unidade antes de gerar a nota.'];
        }

        $requiredConfigFields = [
            'tb26_serie' => 'Serie fiscal',
            'tb26_razao_social' => 'Razao social',
            'tb26_ie' => 'Inscricao estadual',
            'tb26_crt' => 'CRT',
            'tb26_logradouro' => 'Logradouro',
            'tb26_numero' => 'Numero',
            'tb26_bairro' => 'Bairro',
            'tb26_codigo_municipio' => 'Codigo do municipio IBGE',
            'tb26_municipio' => 'Municipio',
            'tb26_uf' => 'UF',
            'tb26_cep' => 'CEP',
            'tb26_certificado_tipo' => 'Tipo de certificado',
            'tb26_certificado_nome' => 'Nome do certificado',
            'tb26_certificado_cnpj' => 'CNPJ do certificado',
            'tb26_certificado_arquivo' => 'Arquivo do certificado A1',
        ];

        foreach ($requiredConfigFields as $field => $label) {
            if (blank($config->{$field})) {
                $errors[] = sprintf('%s nao configurado na unidade.', $label);
            }
        }

        if ($this->fiscalCertificateService->resolveConfigurationPassword($config) === null) {
            $errors[] = 'Senha do certificado nao configurada na unidade ou ilegivel neste ambiente.';
        }

        if (! $config->tb26_emitir_nfe && ! $config->tb26_emitir_nfce) {
            $errors[] = 'Selecione se a unidade vai emitir NF-e, NFC-e ou ambas.';
        }

        if ($config->tb26_rtc_2026_ativa) {
            $regime = (string) $config->tb26_regime_tributario;
            $expectedCrt = $regime === 'simples_nacional' ? 1 : 3;

            if (! in_array($regime, ['simples_nacional', 'lucro_presumido', 'lucro_real'], true)) {
                $errors[] = 'Regime tributario RTC 2026 nao configurado na loja.';
            } elseif ((int) $config->tb26_crt !== $expectedCrt) {
                $errors[] = sprintf('O regime %s exige CRT %d na configuracao fiscal desta loja.', str_replace('_', ' ', $regime), $expectedCrt);
            }
        }

        if ($config->tb26_certificado_valido_ate && $config->tb26_certificado_valido_ate->isPast()) {
            $errors[] = 'O certificado digital da loja esta vencido.';
        }

        if ($modelo === 'nfe') {
            $errors[] = 'NF-e modelo 55 ainda nao pode ser gerada automaticamente porque a venda atual nao armazena destinatario fiscal.';
        }

        if ($consumer !== null) {
            $consumerType = $this->resolveConsumerType($consumer);
            $document = $this->onlyDigits($consumer['document'] ?? null);
            $cep = $this->onlyDigits($consumer['cep'] ?? null);
            $cityCode = $this->onlyDigits($consumer['city_code'] ?? null);
            $state = strtoupper(trim((string) ($consumer['state'] ?? '')));

            if (! in_array($consumerType, ['cupom_fiscal', 'consumidor'], true)) {
                $errors[] = 'Tipo de identificacao do consumidor invalido para a nota fiscal.';
            }

            if ($consumerType === 'consumidor' && trim((string) ($consumer['name'] ?? '')) === '') {
                $errors[] = 'Nome do consumidor nao informado para a NF Consumidor.';
            }

            if ($consumerType === 'cupom_fiscal' && strlen($document) !== 11) {
                $errors[] = 'Documento do consumidor invalido. Informe um CPF com 11 digitos para o cupom fiscal.';
            }

            if ($consumerType === 'consumidor' && ! in_array(strlen($document), [11, 14], true)) {
                $errors[] = 'Documento do consumidor invalido. Informe CPF com 11 digitos ou CNPJ com 14 digitos.';
            }

            if ($consumerType === 'consumidor' && trim((string) ($consumer['street'] ?? '')) === '') {
                $errors[] = 'Logradouro do consumidor nao informado para a NF Consumidor.';
            }

            if ($consumerType === 'consumidor' && trim((string) ($consumer['number'] ?? '')) === '') {
                $errors[] = 'Numero do endereco do consumidor nao informado para a NF Consumidor.';
            }

            if ($consumerType === 'consumidor' && trim((string) ($consumer['neighborhood'] ?? '')) === '') {
                $errors[] = 'Bairro do consumidor nao informado para a NF Consumidor.';
            }

            if ($consumerType === 'consumidor' && trim((string) ($consumer['city'] ?? '')) === '') {
                $errors[] = 'Municipio do consumidor nao informado para a NF Consumidor.';
            }

            if ($consumerType === 'consumidor' && strlen($cep) !== 8) {
                $errors[] = 'CEP do consumidor invalido para a NF Consumidor.';
            }

            if ($consumerType === 'consumidor' && strlen($cityCode) !== 7) {
                $errors[] = 'Codigo do municipio IBGE do consumidor invalido para a NF Consumidor.';
            }

            if ($consumerType === 'consumidor' && strlen($state) !== 2) {
                $errors[] = 'UF do consumidor invalida para a NF Consumidor.';
            }

            if (
                $consumerType === 'consumidor'
                && strlen($state) === 2
                && strlen($cityCode) === 7
                && ! $this->fiscalMunicipalityCodeService->matchesUf($state, $cityCode)
            ) {
                $expectedPrefix = $this->fiscalMunicipalityCodeService->expectedPrefixForUf($state);

                $errors[] = sprintf(
                    'O codigo do municipio IBGE %s nao pertence a UF %s do consumidor. Use um codigo iniciado por %s.',
                    $cityCode !== '' ? $cityCode : '--',
                    $state !== '' ? $state : '--',
                    $expectedPrefix ?? '--'
                );
            }
        }

        $unitCnpj = $this->onlyDigits($payment->vendas->first()?->unidade?->tb2_cnpj);
        $certificateCnpj = $this->onlyDigits($config->tb26_certificado_cnpj);

        if ($unitCnpj && $certificateCnpj && substr($unitCnpj, 0, 8) !== substr($certificateCnpj, 0, 8)) {
            $errors[] = 'O CNPJ do certificado nao pertence ao mesmo CNPJ base da loja da venda.';
        }

        if ($config->tb26_emitir_nfce) {
            if (blank($config->tb26_csc_id)) {
                $errors[] = 'CSC ID nao configurado para NFC-e.';
            }

            if (blank($config->tb26_csc)) {
                $errors[] = 'CSC nao configurado para NFC-e.';
            }
        }

        if (
            (bool) $config->tb26_exigir_tef_integrado
            && $this->isElectronicPaymentType($payment->tipo_pagamento)
            && ! (bool) $payment->tef_integrado
        ) {
            $errors[] = 'A configuracao fiscal desta loja exige TEF integrado para cartao, Pix e pagamentos mistos com complemento eletronico.';
        }

        if ((bool) $payment->tef_integrado) {
            if (! $this->isElectronicPaymentType($payment->tipo_pagamento)) {
                $errors[] = 'TEF integrado foi informado para uma forma de pagamento que nao usa meio eletronico.';
            }

            if (blank($payment->tef_autorizacao)) {
                $errors[] = 'Codigo de autorizacao ou identificacao do pedido TEF nao informado.';
            }

            if (strlen((string) $this->onlyDigits($payment->tef_cnpj_credenciadora)) !== 14) {
                $errors[] = 'CNPJ da credenciadora, subcredenciadora ou intermediador TEF invalido.';
            }

            if ($this->isCardPaymentType($payment->tipo_pagamento) && blank($payment->tef_bandeira)) {
                $errors[] = 'Bandeira do cartao TEF nao informada.';
            }
        }

        if (
            filled($config->tb26_uf)
            && filled($config->tb26_codigo_municipio)
            && ! $this->fiscalMunicipalityCodeService->matchesUf($config->tb26_uf, $config->tb26_codigo_municipio)
        ) {
            $expectedPrefix = $this->fiscalMunicipalityCodeService->expectedPrefixForUf($config->tb26_uf);

            $errors[] = sprintf(
                'O codigo do municipio IBGE %s nao pertence a UF %s informada na configuracao fiscal. Use um codigo iniciado por %s.',
                (string) $config->tb26_codigo_municipio,
                (string) $config->tb26_uf,
                $expectedPrefix ?? '--'
            );
        }

        if (! $this->isValidStateRegistration($config->tb26_ie)) {
            $errors[] = 'A inscricao estadual da unidade esta invalida para emissao fiscal. Informe apenas digitos ou ISENTO.';
        }

        if ($eligibleSales->isEmpty()) {
            $excludedSummary = collect($excludedItems)
                ->map(fn (array $item) => sprintf('%d (%s)', (int) $item['produto_id'], (string) $item['descricao']))
                ->implode(', ');

            $errors[] = $excludedSummary !== ''
                ? sprintf(
                    'Nenhum item da venda possui dados fiscais minimos para gerar a nota. Itens excluidos: %s.',
                    $excludedSummary
                )
                : 'Nenhum item da venda possui dados fiscais minimos para gerar a nota.';
        }

        foreach ($eligibleSales as $sale) {
            /** @var Produto|null $product */
            $product = $sale->produto;
            $productId = (int) $sale->tb1_id;
            $productName = $this->resolveFiscalProductName($sale);

            if (! $product) {
                $errors[] = sprintf('Produto %d nao encontrado para a emissao fiscal.', $productId);
                continue;
            }

            $missingFields = [];
            $invalidNcmMessage = FiscalNcmValidator::invalidMessage($product->tb1_ncm);

            foreach ([
                'tb1_ncm' => 'NCM',
                'tb1_cfop' => 'CFOP',
                'tb1_unidade_comercial' => 'Unidade comercial',
                'tb1_unidade_tributavel' => 'Unidade tributavel',
            ] as $field => $label) {
                if (blank($product->{$field})) {
                    $missingFields[] = $label;
                }
            }

            if ($invalidNcmMessage !== null) {
                $missingFields[] = $invalidNcmMessage;
            }

            if (! $config->tb26_rtc_2026_ativa && blank($product->tb1_csosn) && blank($product->tb1_cst)) {
                $missingFields[] = 'CSOSN/CST';
            }

            if ($config->tb26_rtc_2026_ativa) {
                $tax = $rtcTaxSnapshots[(string) $productId] ?? null;
                if (! is_array($tax)) {
                    $missingFields[] = 'tributacao RTC 2026 por loja';
                } else {
                    foreach (['cst_ibs_cbs' => 'CST IBS/CBS', 'cclass_trib' => 'cClassTrib', 'aliquota_ibs_uf' => 'aliquota IBS UF', 'aliquota_ibs_mun' => 'aliquota IBS municipio', 'aliquota_cbs' => 'aliquota CBS'] as $field => $label) {
                        if (! array_key_exists($field, $tax) || $tax[$field] === null || $tax[$field] === '') {
                            $missingFields[] = $label;
                        }
                    }

                    if ((string) $config->tb26_regime_tributario === 'simples_nacional' && blank($tax['csosn'] ?? null)) {
                        $missingFields[] = 'CSOSN';
                    }

                    if (now()->year === 2026 && (float) ($tax['aliquota_ibs_mun'] ?? 0) !== 0.0) {
                        $missingFields[] = 'aliquota IBS municipio deve ser 0,0000 em 2026';
                    }

                    if (in_array((string) $config->tb26_regime_tributario, ['lucro_presumido', 'lucro_real'], true)) {
                        if (($tax['cst_icms'] ?? null) !== '00') {
                            $missingFields[] = sprintf(
                                'CST ICMS esperado 00 (atual %s)',
                                $this->formatFiscalRuleValue($tax['cst_icms'] ?? null)
                            );
                        }
                        foreach (['cst_pis' => 'CST PIS', 'cst_cofins' => 'CST COFINS'] as $field => $label) {
                            if (! array_key_exists($field, $tax) || $tax[$field] === null || $tax[$field] === '') {
                                $missingFields[] = $label;
                            }
                        }
                        foreach (['aliquota_icms' => 'aliquota ICMS'] as $field => $label) {
                            if (! array_key_exists($field, $tax) || $tax[$field] === null || $tax[$field] === '') {
                                $missingFields[] = $label . ' nao informada';
                            }
                        }
                        foreach (['cst_pis' => ['aliquota_pis', 'aliquota PIS'], 'cst_cofins' => ['aliquota_cofins', 'aliquota COFINS']] as $cstField => [$rateField, $label]) {
                            if (
                                in_array(str_pad((string) ($tax[$cstField] ?? ''), 2, '0', STR_PAD_LEFT), ['01', '02'], true)
                                && (! array_key_exists($rateField, $tax) || $tax[$rateField] === null || $tax[$rateField] === '')
                            ) {
                                $missingFields[] = $label . ' nao informada';
                            }
                        }
                    }
                }
            }

            if ($missingFields !== []) {
                $errors[] = sprintf(
                    'Produto %d (%s) sem cadastro fiscal completo: %s.',
                    $productId,
                    $productName,
                    implode(', ', $missingFields)
                );
            }
        }

        return array_values(array_unique($errors));
    }

    private function formatFiscalRuleValue(mixed $value): string
    {
        $value = trim((string) $value);

        return $value !== '' ? $value : 'nao informado';
    }

    private function resolveRtcTaxSnapshots(
        ?NotaFiscal $invoice,
        $sales,
        ?ConfiguracaoFiscal $config,
        int $unitId,
        bool $refreshFiscalConfiguration = false,
    ): array
    {
        if (! $config?->tb26_rtc_2026_ativa) {
            return [];
        }

        $storedSnapshot = is_array($invoice?->tb27_payload)
            ? ($invoice->tb27_payload['tributacao_rtc_2026'] ?? null)
            : null;

        if (! $refreshFiscalConfiguration && is_array($storedSnapshot) && $storedSnapshot !== []) {
            return $storedSnapshot;
        }

        $productIds = $sales->pluck('tb1_id')->map(fn ($id) => (int) $id)->unique()->values();
        $rules = ProdutoTributacaoFiscalUnidade::query()
            ->where('tb2_id', $unitId)
            ->where('tb28_ativo', true)
            ->whereIn('tb1_id', $productIds)
            ->get()
            ->keyBy('tb1_id');

        $snapshots = [];
        foreach ($productIds as $productId) {
            $rule = $rules->get($productId);
            if (! $rule) {
                continue;
            }

            $snapshots[(string) $productId] = [
                'regime_tributario' => $config->tb26_regime_tributario,
                'csosn' => $rule->tb28_csosn,
                'cst_icms' => $rule->tb28_cst_icms,
                'aliquota_icms' => $rule->tb28_aliquota_icms,
                'cst_pis' => $rule->tb28_cst_pis,
                'aliquota_pis' => $rule->tb28_aliquota_pis,
                'cst_cofins' => $rule->tb28_cst_cofins,
                'aliquota_cofins' => $rule->tb28_aliquota_cofins,
                'cst_ibs_cbs' => $rule->tb28_cst_ibs_cbs,
                'cclass_trib' => $rule->tb28_cclass_trib,
                'aliquota_ibs_uf' => $rule->tb28_aliquota_ibs_uf,
                'aliquota_ibs_mun' => $rule->tb28_aliquota_ibs_mun,
                'aliquota_cbs' => $rule->tb28_aliquota_cbs,
                'reducao_ibs_uf' => $rule->tb28_reducao_ibs_uf,
                'reducao_ibs_mun' => $rule->tb28_reducao_ibs_mun,
                'reducao_cbs' => $rule->tb28_reducao_cbs,
            ];
        }

        return $snapshots;
    }

    private function resolveConsumerPayload(?NotaFiscal $invoice, ?array $consumer): ?array
    {
        if (is_array($consumer)) {
            return $this->normalizeConsumerPayload($consumer);
        }

        $payload = is_array($invoice?->tb27_payload) ? $invoice->tb27_payload : [];
        $storedConsumer = $payload['consumer'] ?? null;

        return is_array($storedConsumer) ? $this->normalizeConsumerPayload($storedConsumer) : null;
    }

    private function normalizeConsumerPayload(?array $consumer): ?array
    {
        if (! is_array($consumer)) {
            return null;
        }

        $normalized = [
            'type' => $this->resolveConsumerType($consumer),
            'name' => trim((string) ($consumer['name'] ?? '')),
            'document' => $this->onlyDigits($consumer['document'] ?? null),
            'cep' => $this->onlyDigits($consumer['cep'] ?? null),
            'street' => trim((string) ($consumer['street'] ?? '')),
            'number' => trim((string) ($consumer['number'] ?? '')),
            'complement' => trim((string) ($consumer['complement'] ?? '')),
            'neighborhood' => trim((string) ($consumer['neighborhood'] ?? '')),
            'city' => trim((string) ($consumer['city'] ?? '')),
            'city_code' => $this->onlyDigits($consumer['city_code'] ?? null),
            'state' => strtoupper(trim((string) ($consumer['state'] ?? ''))),
        ];

        if ($normalized['type'] === 'cupom_fiscal') {
            $normalized['name'] = '';
            $normalized['cep'] = null;
            $normalized['street'] = '';
            $normalized['number'] = '';
            $normalized['complement'] = '';
            $normalized['neighborhood'] = '';
            $normalized['city'] = '';
            $normalized['city_code'] = null;
            $normalized['state'] = '';
        }

        return $normalized;
    }

    private function resolveConsumerType(array $consumer): string
    {
        $declaredType = trim((string) ($consumer['type'] ?? ''));

        if (in_array($declaredType, ['cupom_fiscal', 'consumidor'], true)) {
            return $declaredType;
        }

        $document = $this->onlyDigits($consumer['document'] ?? null);
        $name = trim((string) ($consumer['name'] ?? ''));

        if ($document && $name === '') {
            return 'cupom_fiscal';
        }

        return 'consumidor';
    }

    private function resolveStatus(?ConfiguracaoFiscal $config, array $errors): string
    {
        if (! $config) {
            return 'pendente_configuracao';
        }

        if ($errors !== []) {
            return 'erro_validacao';
        }

        return 'pendente_emissao';
    }

    private function buildStatusMessage(string $status, array $errors, array $payload): string
    {
        $excludedCount = (int) ($payload['itens_excluidos_qtd'] ?? 0);

        if ($status === 'pendente_emissao' && ($payload['tipo_pagamento'] ?? null) === 'dinheiro') {
            return 'Nota fiscal aguardando assinatura manual para transmissao. Enquanto isso, imprima apenas o cupom nao fiscal.';
        }

        return match ($status) {
            'xml_assinado' => $excludedCount > 0
                ? sprintf(
                    'XML fiscal assinado localmente e aguardando transmissao para a SEFAZ. %d item(ns) sem cadastro fiscal minimo ficaram fora da nota.',
                    $excludedCount
                )
                : 'XML fiscal assinado localmente e aguardando transmissao para a SEFAZ.',
            'pendente_emissao' => $excludedCount > 0
                ? sprintf(
                    'Nota preparada e aguardando integracao com a SEFAZ. %d item(ns) sem cadastro fiscal minimo ficaram fora da nota.',
                    $excludedCount
                )
                : 'Nota preparada e aguardando integracao com a SEFAZ.',
            'erro_validacao' => $errors !== []
                ? implode(' ', array_map(fn (string $error): string => rtrim($error, '.') . '.', $errors))
                : 'A nota possui pendencias fiscais.',
            default => 'A unidade ainda nao possui configuracao fiscal suficiente para emitir.',
        };
    }

    private function splitSalesForFiscal(VendaPagamento $payment): array
    {
        $eligibleSales = collect();
        $excludedItems = [];

        foreach ($payment->vendas as $sale) {
            /** @var Produto|null $product */
            $product = $sale->produto;
            $missingFields = [];

            if (! $product) {
                $missingFields = ['Produto nao encontrado'];
            } else {
                if (blank($product->tb1_ncm)) {
                    $missingFields[] = 'NCM';
                }

                if (blank($product->tb1_cfop)) {
                    $missingFields[] = 'CFOP';
                }

                if (blank($product->tb1_csosn) && blank($product->tb1_cst)) {
                    $missingFields[] = 'CSOSN/CST';
                }
            }

            if ($missingFields === []) {
                $eligibleSales->push($sale);
                continue;
            }

            $excludedItems[] = [
                'produto_id' => (int) $sale->tb1_id,
                'descricao' => $this->resolveFiscalProductName($sale),
                'motivo' => sprintf(
                    'Item fora da nota por falta de: %s.',
                    implode(', ', $missingFields)
                ),
                'campos_faltantes' => $missingFields,
                'valor_total' => round((float) $sale->valor_total, 2),
            ];
        }

        return [$eligibleSales, $excludedItems];
    }

    private function resolveFiscalProductName($sale): string
    {
        $currentName = trim((string) ($sale->produto?->tb1_nome ?? ''));

        if ($currentName !== '') {
            return $currentName;
        }

        return trim((string) ($sale->produto_nome ?? ''));
    }

    private function onlyDigits(?string $value): ?string
    {
        $value = preg_replace('/\D+/', '', (string) $value);

        return $value === '' ? null : $value;
    }

    private function isValidStateRegistration(?string $value): bool
    {
        $value = strtoupper(trim((string) $value));

        if ($value === 'ISENTO') {
            return true;
        }

        $digits = $this->onlyDigits($value);

        return $digits !== null && strlen($digits) >= 2 && strlen($digits) <= 14;
    }

    private function isLockWaitTimeout(QueryException $exception): bool
    {
        $message = strtolower($exception->getMessage());

        return str_contains($message, 'lock wait timeout exceeded')
            || str_contains($message, 'deadlock found')
            || in_array((string) $exception->getCode(), ['1205', '1213'], true);
    }

    private function supportsAutomaticFiscalGenerationForPaymentType(?string $paymentType): bool
    {
        return in_array((string) $paymentType, [
            'dinheiro',
            'cartao_credito',
            'cartao_debito',
            'pix',
            'dinheiro_cartao_credito',
            'dinheiro_cartao_debito',
            'dinheiro_pix',
            'maquina',
        ], true);
    }

    private function shouldPrepareFiscalInvoiceForNewPayment(
        ?ConfiguracaoFiscal $config,
        ?string $paymentType,
        bool $bypassFiscalGenerationDisabled = false,
    ): bool {
        if (! $config) {
            return false;
        }

        if ($bypassFiscalGenerationDisabled) {
            return true;
        }

        return $config->tb26_geracao_automatica_ativa
            || $this->requiresFiscalGenerationDespiteDisabledAutomaticGeneration($config, $paymentType);
    }

    private function requiresFiscalGenerationDespiteDisabledAutomaticGeneration(
        ConfiguracaoFiscal $config,
        ?string $paymentType,
    ): bool {
        if ((string) $config->tb26_regime_tributario !== 'lucro_presumido') {
            return false;
        }

        return in_array((string) $paymentType, [
            'cartao_credito',
            'cartao_debito',
            'pix',
            'dinheiro_cartao_credito',
            'dinheiro_cartao_debito',
            'dinheiro_pix',
            'maquina',
        ], true);
    }

    private function shouldDeferFiscalSignatureForPayment(?string $paymentType, bool $forceFiscalSignature): bool
    {
        return (string) $paymentType === 'dinheiro' && ! $forceFiscalSignature;
    }

    private function isElectronicPaymentType(?string $paymentType): bool
    {
        return in_array((string) $paymentType, [
            'cartao_credito',
            'cartao_debito',
            'pix',
            'maquina',
            'dinheiro_cartao_credito',
            'dinheiro_cartao_debito',
            'dinheiro_pix',
        ], true);
    }

    private function isCardPaymentType(?string $paymentType): bool
    {
        return in_array((string) $paymentType, [
            'cartao_credito',
            'cartao_debito',
            'maquina',
            'dinheiro_cartao_credito',
            'dinheiro_cartao_debito',
        ], true);
    }

    private function buildNonFiscalPaymentMessage(?string $paymentType): string
    {
        $label = match ((string) $paymentType) {
            'pix' => 'Pix',
            'vale' => 'Vale',
            'refeicao' => 'Refeicao',
            'faturar' => 'Faturar',
            default => strtoupper(str_replace('_', ' ', trim((string) $paymentType))) ?: 'NAO INFORMADO',
        };

        return sprintf(
            'Pagamento %s e apenas controle interno e nao gera nota fiscal automatica.',
            $label
        );
    }
}
